from .mlp import MultiLayerPerceptron
from .perceptron import Perceptron
from .svm import SVM
